package com.teretana.dao;

import org.springframework.data.repository.CrudRepository;



public interface KnjigaTreninga extends CrudRepository<KnjigaTreninga, Long> {

}

