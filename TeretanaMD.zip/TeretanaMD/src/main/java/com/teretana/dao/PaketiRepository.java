package com.teretana.dao;

import org.springframework.data.repository.CrudRepository;

import com.teretana.model.Paketi;

public interface PaketiRepository extends CrudRepository<Paketi, Long> {

    

	
    
}
