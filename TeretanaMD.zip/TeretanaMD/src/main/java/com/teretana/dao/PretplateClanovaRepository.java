package com.teretana.dao;

import org.springframework.data.repository.CrudRepository;

import com.teretana.model.PretplateClanova;




public interface PretplateClanovaRepository extends CrudRepository<PretplateClanova, Long> {

}

