package com.teretana.dao;

import org.springframework.data.repository.CrudRepository;

import com.teretana.model.Trener;

public interface TrenerRepository extends CrudRepository<Trener, Long> {

}

